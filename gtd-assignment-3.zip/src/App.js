import './App.css';
import './output.css';
import Navbar from './Navbar.js';
import Body from './Body.js';
import Sidebar from './Sidebar.js';

function App() {
  return (
    <>
      <Sidebar />
      <Navbar />
      <Body />
    </>
  );
}

export default App;
