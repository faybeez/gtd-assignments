import todoData from "./db.js";
import editIcon from "./img/edit_icon.png";
import editPage from "./Body.js";

const Home = () => {

    const completeTask = item => {
        return;
    }
    //<input type="checkbox" value={false} onChange={completeTask}/>

    const filteredData = todoData.filter((data) => data.status === "notC");

    const ListItem = filteredData.map((item) =>
        <div class="flex justify-between overflow-hidden border-b-2 border-gray-200 py-2">
            <div class="w-4/5 flex">
                <p class="mx-6 font-semibold text-lg">{item.title}</p>
                <button onClick={editPage}><img class="w-4 opacity-40 hover:opacity-80 z-0" src={editIcon}></img></button>
            </div>
            <p class="mx-4 w-1/5 font-semibold text-lg text-right">{item.duedate}</p>   
        </div>
    );

    return (
        <div class="m-4 visible" id="home">
            <div class="w-full flex justify-between border-b-2 pb-2 border-gray-200">
                <p class="mx-4 font-bold text-2xl">Title</p>
                <p class="mx-4 font-bold text-2xl">Due</p>
            </div>
            {ListItem}
        </div>

    );

}

export default Home;