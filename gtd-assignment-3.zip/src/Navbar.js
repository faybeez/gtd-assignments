import icon from './img/Hamburger_icon.png';

const Navbar = () => {

    function SidebarClick() {
        document.getElementById("sidebar").style.visibility = "visible";    
        document.getElementById("sidebar").style.opacity = "1";    
        document.getElementById("bar").style.right = "0px";

    }

    return (  
        <div className="flex justify-between px-10 py-3 rounded-b-lg shadow-lg items-center z-0">
            <span className='flex items-center font-bold text-3xl'>Next Todo App</span>
            <button className='rounded-lg p-3 border border-gray-300 hover:bg-gray-200' onClick={SidebarClick}><img src={icon} className='w-6'></img></button>
        </div>
    );
}
 
export default Navbar;