export const todoData = [
    {
        "id": 0,
        "title": 'SC1005',
        "priority": 'Low',
        "duedate": '11/23/2024',
        "description": 'lalalalala',
        "status": "notC"
    },
    {
        "id": 1,
        "title": 'test 2',
        "priority": 'Medium',
        "duedate": '15/23/2024',
        "description": 'asdsajksjkasdjkj',
        "status":"notC",
    },
    {
        "id": 2,
        "title": 'SC1003',
        "priority": 'Low',
        "duedate": '12/23/2024',
        "description": 'lalalalala',
        "status":"C",
    },
]

export default todoData;