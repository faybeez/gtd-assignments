import xIcon from './img/x_icon.png';
import createPage from './Body.js';
import completedPage from './Body.js';
import homePage from './Body.js';

const Sidebar = () => {

  function closeSidebar() {
    document.getElementById("bar").style.right = "-100px";
    document.getElementById("sidebar").style.opacity = "0";
    document.getElementById("sidebar").style.visibility = "hidden"; 

  }

    return (
      <div class="flex justify-end z-1 w-screen absolute backdrop-blur invisible opacity-0 h-screen transition-all duration-700" id="sidebar">
        <div class="w-full" onClick={closeSidebar}></div>
        <div class=" w-1/4 fixed h-full right-[-100px] transition-all duration-700 shadow-xl rounded-l-3xl bg-white p-8" onClick={null} id="bar">
          <div class=""></div>

          <div class="w-full flex justify-between border-b-2 pb-2 border-gray-200">
            <p class="font-bold text-2xl">Navigate</p>
            <img class="w-4 h-4 rounded-s hover:bg-slate-300" onClick={closeSidebar} src={xIcon}></img>
          </div>

          <button class="mt-2 rounded-lg w-full h-12 text-xl font-semibold hover:bg-slate-200 text-left px-4" onClick={homePage}>Home</button>
          <button class="mt-2 rounded-lg w-full h-12 text-xl font-semibold hover:bg-slate-200 text-left px-4" onClick={createPage}>New</button>
          <button class="mt-2 rounded-lg w-full h-12 text-xl font-semibold hover:bg-slate-200 text-left px-4" onClick={completedPage}>Completed</button>
        </div>
      </div>
    );
}

export default Sidebar;