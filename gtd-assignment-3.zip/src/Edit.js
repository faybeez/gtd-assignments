const Edit = () => {

    return (
        <div class="m-8" id="createpage">
            <div class="w-full block border-b-2 pb-2 border-gray-200">
                <p class=" font-bold text-2xl">Edit Task</p>
            </div>
            <form class="grid m-4">
                <label class="font-semibold text-xl">Title</label>
                <input type="text" class="mt-2 mb-6 p-2 rounded-lg border-2 border-gray-200"></input>

                <label class="font-semibold text-xl">Priority</label>
                <select class="mt-2 mb-6 p-2 rounded-lg border-2 border-gray-200">
                    <option disabled selected value></option>
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                </select>

                <label class="font-semibold text-xl">Due Date</label>
                <input type="date" class="mt-2 mb-6 p-2 rounded-lg border-2 border-gray-200"></input>

                <label class="font-semibold text-xl">Description</label>
                <textarea rows="4" class="mt-2 mb-6 p-2 rounded-lg border-2 border-gray-200 overflow-auto"></textarea>

                <input type="submit" class="w-48 p-2 border-2 border-collapse border-slate-200 rounded-xl hover:bg-slate-200" value="Save Changes"></input>
            </form>
        </div>

    );

}

export default Edit;