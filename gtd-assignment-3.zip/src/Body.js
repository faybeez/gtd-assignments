import { useState } from "react";
import Home from "./Home.js";
import Create from "./Create.js";
import Edit from "./Edit.js";
import Completed from "./Completed.js";

const Body = () => {

    //kalo mau liat page lain, ganti usestate jd (1-create, 2-completed, 3-edit) vv
    const [page, setPage] = useState(0);

    function homePage() {
        setPage(0);
    }

    function createPage() {
        setPage(1);
    }

    function completedPage() {
        setPage(2);
    }

    function editPage() {
        setPage(3);
    }

    if(page === 0) {
        return <Home></Home>;
    }
    else if (page === 1) {
        return <Create></Create>;
    }
    else if (page === 2) {
        return <Completed></Completed>;
    }
    else if (page === 3) {
        return <Edit></Edit>;
    }
}


export default Body;