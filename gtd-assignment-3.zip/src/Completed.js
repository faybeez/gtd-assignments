import todoData from "./db.js";

const Completed = () => {
    
        const filteredData = todoData.filter((data) => data.status === "C");
    
        const ListItem = filteredData.map((item) =>
            <div class="flex justify-between overflow-hidden border-b-2 border-gray-200 py-2">
                <div class="w-4/5 flex">
                    <p class="mx-6 font-semibold text-lg">{item.title}</p>
                </div>
                <p class="mx-4 w-1/5 font-semibold text-lg text-right">{item.duedate}</p>   
            </div>
        );

        return (
            <div class="m-4 visible" id="home">
                <div class="w-full flex justify-between border-b-2 pb-2 border-gray-200">
                    <p class="mx-4 font-bold text-2xl">Title</p>
                    <p class="mx-4 font-bold text-2xl">Was Due</p>
                </div>
                {ListItem}
            </div>
    
        );
}
export default Completed;